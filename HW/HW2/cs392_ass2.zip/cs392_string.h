//"I pledge my honor that I have abided by the Stevens honor system" - igomez1 Ian Gomez
#ifndef CS_392STRLEN
#define CS_392STRLEN
unsigned int cs392_strlen(char *str);
#endif
#ifndef CS_392MEMCPY
#define CS_392MEMCPY
void * cs392_memcpy(void * dst, void * src, unsigned num);
#endif

