#ifndef __SUM_H__
#define __SUM_H__

int add_2_num(int, int);
int add_3_num(int, int, int);

#endif
