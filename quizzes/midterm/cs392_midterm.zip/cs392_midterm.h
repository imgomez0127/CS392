//"I pledge my honor that I have abided by the Stevens honor system"-igomez1 Ian Gomez
#ifndef STRCMP
#define STRCMP
int cs392_strcmp(char *s1, char *s2);
#endif
#ifndef STRCPY
#define STRCPY
char *cs392_strcpy(char *dest, char *src);
#endif
#ifndef STRNCAT
#define STRNCAT
char * cs392_strncat(char *dest, char *src, unsigned int n);
#endif
